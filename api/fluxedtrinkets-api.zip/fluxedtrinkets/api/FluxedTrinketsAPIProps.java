package fluxedtrinkets.api;

public class FluxedTrinketsAPIProps {

	private FluxedTrinketsAPIProps() {

	}

	public static final String VERSION = "0.45";

}
