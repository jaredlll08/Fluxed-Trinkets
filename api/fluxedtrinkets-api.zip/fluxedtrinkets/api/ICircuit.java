package fluxedtrinkets.api;

public interface ICircuit {
	

	public CircuitTiers getTier();
	
	public String getEffect();
	
}
