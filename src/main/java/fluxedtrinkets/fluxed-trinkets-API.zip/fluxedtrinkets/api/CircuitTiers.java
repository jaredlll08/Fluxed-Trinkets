/**
 * 
 */
package fluxedtrinkets.api;

public enum CircuitTiers {
	basic, advanced
}
