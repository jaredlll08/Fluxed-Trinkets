@API(apiVersion = FluxedTrinketsAPIProps.VERSION, owner = "fluxedtrinkets", provides="fluxedtrinketsAPI")
package fluxedtrinkets.api;

import cpw.mods.fml.common.API;

